import React, { useState } from 'react';
import contact from '../assets/contact.jpg';

function Contact() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    alert('Contact Form Submitted');
  };

  return (
    <section id="contact" className="py-16 bg-gradient-to-r from-gray-800 via-gray-900 to-black dark:bg-gradient-to-r dark:from-gray-800 dark:via-gray-900 dark:to-black">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row items-center gap-12">
          {/* Left Content */}
          <div className="flex-1 space-y-8 text-white">
            <h2 className="text-4xl font-bold">Contact Me</h2>
            <p className="text-lg max-w-xl text-gray-400">
              We'd love to hear from you. Whether you have a question, feedback, or just want to chat, feel free to reach out!
            </p>

            {/* Contact Form */}
            <form onSubmit={handleSubmit} className="space-y-6 mt-6">
              <div>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full p-4 text-gray-700 bg-gray-900 border-2 border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 transition-all"
                  placeholder="Your Full Name"
                  required
                />
              </div>

              <div>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full p-4 text-gray-700 bg-gray-900 border-2 border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 transition-all"
                  placeholder="Your Email Address"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-blue-600 text-white rounded-lg text-lg font-medium hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
              >
                Send Message
              </button>
            </form>
          </div>

          {/* Right Image */}
          <div className="flex-1 max-w-lg">
            <div className="relative rounded-lg overflow-hidden shadow-xl">
              <img
                src={contact}
                alt="Contact"
                className="w-full h-full object-cover transform transition-transform hover:scale-105"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Contact;
