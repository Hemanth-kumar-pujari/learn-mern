import React from 'react';
import { GraduationCap, Calendar, Award, Code } from 'lucide-react';

function Education() {
  const education = [
    {
      school: "Sree vidyanikethan engineering college",
      year: "2020 - 2024",
      cgpa: "9.29",
      skills: ["Computer Science", "Machine Learning", "Web Development"]
    },
    {
      school: "sree chaitanya junior college",
      year: "2018 - 2020",
      cgpa: "9.58",
      skills: ["Mathematics", "Physics", "Chemistry"]
    },
    {
      school: "Z P H S (central) high school",
      year: "2016 - 2018",
      cgpa: "9.3",
      skills: ["Mathematics", "English", "science and social studies", "Hindi"]
    }
  ];

  return (
    <section id="education" className="py-20 bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 dark:text-white mb-4">Education</h2>
          <div className="w-20 h-1 bg-blue-600 mx-auto"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {education.map((edu, index) => (
            <div 
              key={index}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow duration-300"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-blue-100 dark:bg-blue-600 rounded-lg">
                  <GraduationCap className="w-6 h-6 text-blue-600 dark:text-blue-200" />
                </div>
                <h3 className="text-xl font-bold text-gray-800 dark:text-gray-200">{edu.school}</h3>
              </div>

              <div className="space-y-3">
                <div className="flex items-center gap-2 text-gray-600 dark:text-gray-400">
                  <Calendar className="w-4 h-4" />
                  <span>{edu.year}</span>
                </div>

                <div className="flex items-center gap-2 text-gray-600 dark:text-gray-400">
                  <Award className="w-4 h-4" />
                  <span>CGPA: {edu.cgpa}</span>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-gray-600 dark:text-gray-400">
                    <Code className="w-4 h-4" />
                    <span>Key Skills:</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {edu.skills.map((skill, skillIndex) => (
                      <span 
                        key={skillIndex}
                        className="px-3 py-1 bg-blue-50 dark:bg-blue-700 text-blue-600 dark:text-blue-200 rounded-full text-sm"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Education;
