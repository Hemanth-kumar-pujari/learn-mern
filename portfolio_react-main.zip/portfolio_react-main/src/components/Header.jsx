import React, { useState } from 'react';
import { Menu, X, Briefcase, GraduationCap, Home, User2, Code2, Mail } from 'lucide-react';

function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const menuItems = [
    { title: 'About', icon: <User2 className="w-5 h-5" /> },
    { title: 'Education', icon: <GraduationCap className="w-5 h-5" /> },
    { title: 'Experience', icon: <Briefcase className="w-5 h-5" /> },
    { title: 'Skills', icon: <Code2 className="w-5 h-5" /> },
    { title: 'Contact', icon: <Mail className="w-5 h-5" /> },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 bg-gray-900 shadow-md z-50">
      <nav className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <Home className="w-6 h-6 text-blue-400" />
            <span className="text-xl font-bold text-white">Portfolio</span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {menuItems.map((item) => (
              <a
                key={item.title}
                href={`#${item.title.toLowerCase()}`}
                className="flex items-center space-x-1 text-gray-300 hover:text-blue-400 transition-colors"
              >
                {item.icon}
                <span>{item.title}</span>
              </a>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2 rounded-lg hover:bg-gray-800"
            onClick={() => setIsMenuOpen(true)}
          >
            <Menu className="w-6 h-6 text-gray-300" />
          </button>
        </div>
      </nav>

      {/* Mobile Menu Modal */}
      {isMenuOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 md:hidden z-50">
          <div className="fixed inset-y-0 right-0 w-64 bg-gray-800 shadow-lg">
            <div className="flex justify-between items-center p-4 border-b border-gray-700">
              <span className="text-xl font-bold text-white">Menu</span>
              <button
                className="p-2 rounded-lg hover:bg-gray-700"
                onClick={() => setIsMenuOpen(false)}
              >
                <X className="w-6 h-6 text-gray-300" />
              </button>
            </div>
            <div className="py-4">
              {menuItems.map((item) => (
                <a
                  key={item.title}
                  href={`#${item.title.toLowerCase()}`}
                  className="flex items-center space-x-2 px-4 py-3 hover:bg-gray-700 text-gray-300"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.icon}
                  <span>{item.title}</span>
                </a>
              ))}
            </div>
          </div>
        </div>
      )}
    </header>
  );
}

export default Header;
