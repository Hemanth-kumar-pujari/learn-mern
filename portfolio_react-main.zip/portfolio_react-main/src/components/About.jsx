import React from "react";
import { Github, Linkedin, Twitter, Download } from "lucide-react";
import resume from "../assets/hemanth_kumar_p.pdf"; // import statement
import myphoto from "../assets/my_image.png";

function About() {
  return (
    <section id="about" className="py-20 bg-gray-900">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center gap-12">
          {/* Left Content */}
          <div className="flex-1 space-y-6">
            <div className="space-y-2">
              <h1 className="text-4xl md:text-5xl font-bold text-white">
                Hemanth Kumar
              </h1>
              <h2 className="text-xl md:text-2xl text-blue-400 font-semibold">
                Full Stack Developer
              </h2>
            </div>

            <p className="text-gray-300 text-lg leading-relaxed">
              I am seeking a position within an organization where I can apply
              the knowledge and skills acquired through my studies to contribute
              towards achieving both immediate and long-term goals of the
              industry.
            </p>

            {/* Social Icons */}
            <div className="flex gap-4">
              <a
                href="https://github.com/hacker-phk/"
                className="p-2 text-gray-400 hover:text-blue-400 transition-colors"
                aria-label="Github"
              >
                <Github className="w-6 h-6" />
              </a>
              <a
                href="https://www.linkedin.com/in/hemanthkumarpujari/"
                className="p-2 text-gray-400 hover:text-blue-400 transition-colors"
                aria-label="LinkedIn"
              >
                <Linkedin className="w-6 h-6" />
              </a>
              <a
                href="https://x.com/wr1phk"
                className="p-2 text-gray-400 hover:text-blue-400 transition-colors"
                aria-label="Twitter"
              >
                <Twitter className="w-6 h-6" />
              </a>
            </div>

            {/* Download Resume Button */}
            <a
              href={resume} // Use the imported resume variable
              download
              className="mt-6 inline-flex items-center px-6 py-3 bg-blue-600 text-white font-semibold rounded-full hover:bg-blue-700 transition-colors"
              aria-label="Download Resume"
            >
              <Download className="w-5 h-5 mr-2" />
              Download Resume
            </a>
          </div>

          {/* Right Image */}
          <div className="flex-1">
            <div className="relative">
              <div className="absolute -inset-4  rounded-lg transform rotate-3 transition-transform group-hover:rotate-6"></div>
              <img
                src={myphoto}
                alt="Profile"
                className="relative w-full h-auto  shadow-lg object-cover transform transition-transform hover:scale-100 rounded-[25%]"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default About;
