import React from "react";
import { Code, Database, Terminal, BarChart, Cpu, Server } from "lucide-react";

const Skills = () => {
  const skills = [
    { name: "MERN Stack", icon: <Code className="text-blue-500" />, details: "MongoDB, Express, React, Node.js" },
    { name: "Java for DSA", icon: <Code className="text-red-500" />, details: "Efficient algorithms and data structures" },
    { name: "Python Basics", icon: <Terminal className="text-yellow-500" />, details: "Fundamentals and scripting" }, // Changed to Terminal for Python
    { name: "MySQL", icon: <Database className="text-teal-600" />, details: "Database management and queries" },
    { name: "JDBC", icon: <Server className="text-gray-600" />, details: "Java Database Connectivity" },
    { name: "Tailwind CSS", icon: <Code className="text-purple-500" />, details: "Responsive UI design" },
    { name: "ML Basics", icon: <BarChart className="text-green-500" />, details: "Introduction to machine learning" },
  ];

  return (
    <section className="bg-gray-100 dark:bg-gray-900 py-10 px-5 sm:px-10" id="skills">
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold text-gray-800 dark:text-white mb-4">Skills</h2>
        <div className="w-20 h-1 bg-blue-600 mx-auto"></div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {skills.map((skill, index) => (
          <div
            key={index}
            className="group flex flex-col items-center p-6 bg-white dark:bg-gray-800 shadow-lg rounded-lg transition-transform transform hover:scale-105 hover:shadow-xl"
          >
            <div className="text-4xl mb-4">{skill.icon}</div>
            <h3 className="text-xl font-semibold mb-2 text-gray-700 dark:text-gray-200">{skill.name}</h3>
            <p className="text-gray-500 dark:text-gray-400 text-center">{skill.details}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Skills;
