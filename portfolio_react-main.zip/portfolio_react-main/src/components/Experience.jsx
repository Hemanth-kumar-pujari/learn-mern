import React from 'react';
import { Briefcase, Calendar, MapPin, CheckCircle } from 'lucide-react';

function Experience() {
  const experiences = [
    {
      title: "Full Stack Developer (MERN) Intern",
      company: "YahWeh Innovations Private Limited",
      period: "Dec 2024 - Present",
      location: "Remote",
      responsibilities: [
        "Develop and maintain web applications using the MERN stack",
        "Collaborate with designers to create responsive and visually appealing user interfaces",
        "Optimize applications for speed and scalability",
        "Assist in troubleshooting and debugging issues",
        "Participate in code reviews and contribute to improving development processes",
        "Ensure that web applications meet high standards of quality, performance, and security"
      ],
      skills: ["React.js", "Express.js", "Node.js", "MongoDB"]
    },
    {
      title: "Web Developer",
      company: "CodSoft",
      period: "Aug 2023 - Oct 2023",
      location: "Remote",
      responsibilities: [
        "Recent development and Version control experience",
        "Frontend development using modern technologies",
        "Collaborative development in a team environment"
      ],
      skills: ["Java Development", "CSS", "HTML", "JavaScript", "Version Control", "Web Development"]
    }
  ];

  return (
    <section id="experience" className="py-20 bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 dark:text-white mb-4">Experience</h2>
          <div className="w-20 h-1 bg-blue-600 mx-auto"></div>
        </div>

        <div className="space-y-8">
          {experiences.map((exp, index) => (
            <div 
              key={index}
              className="bg-white dark:bg-gray-800 rounded-xl p-6 hover:shadow-lg transition-shadow duration-300"
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <div className="p-2 bg-blue-100 dark:bg-blue-600 rounded-lg">
                      <Briefcase className="w-5 h-5 text-blue-600 dark:text-blue-200" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-800 dark:text-gray-200">{exp.title}</h3>
                  </div>
                  <p className="text-lg text-blue-600 dark:text-blue-400 font-semibold">{exp.company}</p>
                </div>
                <div className="mt-2 md:mt-0 space-y-1">
                  <div className="flex items-center gap-2 text-gray-600 dark:text-gray-400">
                    <Calendar className="w-4 h-4" />
                    <span>{exp.period}</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-600 dark:text-gray-400">
                    <MapPin className="w-4 h-4" />
                    <span>{exp.location}</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 space-y-4">
                <div className="space-y-2">
                  <h4 className="font-semibold text-gray-700 dark:text-gray-300">Key Responsibilities:</h4>
                  <ul className="space-y-2">
                    {exp.responsibilities.map((resp, respIndex) => (
                      <li key={respIndex} className="flex items-start gap-2">
                        <CheckCircle className="w-5 h-5 text-green-500 dark:text-green-300 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-600 dark:text-gray-400">{resp}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-700 dark:text-gray-300 mb-2">Technologies:</h4>
                  <div className="flex flex-wrap gap-2">
                    {exp.skills.map((skill, skillIndex) => (
                      <span 
                        key={skillIndex}
                        className="px-3 py-1 bg-blue-50 dark:bg-blue-700 text-blue-600 dark:text-blue-200 rounded-full text-sm"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Experience;
