import React, { useState } from "react";
import Header from "./Header";
import Footer from "./Footer";
import Note from "./Note";
import CreateArea from "./CreateArea";

function App() {
  // State to hold the list of items (notes)
  const [items, setItems] = useState([]);

  // Function to add a new item (note) to the list
  function addItem(title, content) {
    // Create a new object representing the note
    const newObj = {
      title: title,
      content: content,
    };

    // Update the list of items with the new item
    setItems((prevItems) => [...prevItems, newObj]);
  }
  function deleteItem(params) {
    console.log(params);
    var newValues = items.filter((item, index) => {
      return index != params;
    });
    setItems(newValues);
  }

  return (
    <div>
      {/* Header component */}
      <Header />

      {/* Component for creating a new note */}
      <CreateArea fun={addItem} />

      {/* Render each note */}
      {items.map((item, index) => (
        <Note
          key={index}
          title={item.title}
          content={item.content}
          id={index}
          dd={deleteItem}
        />
      ))}

      {/* Footer component */}
      <Footer />
    </div>
  );
}

export default App;
