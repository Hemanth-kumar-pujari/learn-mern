import React from "react";

function Note(props) {
  return (
    <div className="note">
      {/* Render the title */}
      <h1>{props.title}</h1>

      {/* Render the content */}
      <p>{props.content}</p>

      {/* Delete button */}
      <button
        onClick={(event) => {
          event.preventDefault();
          // Call the delete function passed via props, passing the note's id
          const val = props.id;
          props.dd(val);
        }}
      >
        DELETE
      </button>
    </div>
  );
}

export default Note;
