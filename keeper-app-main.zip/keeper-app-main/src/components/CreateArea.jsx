import React, { useState } from "react";

function CreateArea(props) {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  function handle1(params) {
    const val1 = params.target.value;
    setTitle(val1);
  }
  function handle2(params) {
    const val2 = params.target.value;
    setContent(val2);
  }
  return (
    <div>
      <form>
        <input
          name="title"
          placeholder="Title"
          value={title}
          onChange={handle1}
        />
        <textarea
          name="content"
          placeholder="Take a note..."
          rows="3"
          value={content}
          onChange={handle2}
        />
        <button
          onClick={(event) => {
            event.preventDefault();
            setContent("");
            setTitle("");
            props.fun(title, content);
          }}
        >
          Add
        </button>
      </form>
    </div>
  );
}

export default CreateArea;
