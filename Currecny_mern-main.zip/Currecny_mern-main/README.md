
# Expense Tracker

A web application for tracking earnings and expenses, built with React, Vite, Express, and MongoDB. This application supports user authentication with JWT, handles user sessions with cookies, and features functionalities for adding, viewing, and deleting transactions.

## Table of Contents

- [Features](#features)
- [Technologies](#technologies)
- [Setup](#setup)
  - [Frontend Setup](#frontend-setup)
  - [Backend Setup](#backend-setup)
- [API Endpoints](#api-endpoints)
- [Usage](#usage)
- [Contributing](#contributing)
- [License](#license)

## Features

- **User Authentication**: Login and logout functionality using JWT and cookies.
- **Transaction Management**: Add earnings and expenses, view transaction history, and delete transactions.
- **React Frontend**: Built with React and Vite for a fast and modern user experience.
- **Express Backend**: RESTful API using Express.js to handle requests.
- **MongoDB Database**: Mongoose ORM for managing data.
- **CORS Support**: Configured to allow requests from different origins.

## Technologies

- **Frontend**: React, Vite
- **Backend**: Express, Node.js
- **Database**: MongoDB, Mongoose
- **Authentication**: JWT (JSON Web Tokens)
- **Cookies**: For session management
- **CORS**: Cross-Origin Resource Sharing configuration

## Setup

### Frontend Setup

1. **Clone the Repository**:
   ```bash
   git clone https://github.com/yourusername/expense-tracker.git
   cd expense-tracker
   ```

2. **Navigate to Frontend Directory**:
   ```bash
   cd client
   ```

3. **Install Dependencies**:
   ```bash
   npm install
   ```

4. **Start the Development Server**:
   ```bash
   npm run dev
   ```
   The frontend will be available at `http://localhost:3000`.

### Backend Setup

1. **Navigate to Backend Directory**:
   ```bash
   cd server
   ```

2. **Install Dependencies**:
   ```bash
   npm install
   ```

3. **Configure Environment Variables**:
   Create a `.env` file in the `server` directory with the following content:
   ```plaintext
   MONGO_URI=your_mongodb_connection_string
   JWT_SECRET=your_jwt_secret_key
   ```

4. **Start the Backend Server**:
   ```bash
   npm start
   ```
   The backend will be available at `http://localhost:3001`.

## API Endpoints

### Authentication

- **POST /login**: Log in and receive a JWT.
  - Request Body: `{ "email": "user@example.com", "password": "password" }`
  - Response: `{ "token": "jwt_token" }`

- **POST /logout**: Log out by clearing the JWT cookie.

### Transactions

- **GET /all**: Get all transactions for the logged-in user.
  - Response: `[{ "_id": "id", "amount": 100, "title": "title", "description": "description", "type": 1 }]`

- **POST /add**: Add a new transaction (earn or spend).
  - Request Body: `{ "amount": 100, "title": "title", "description": "description", "type": 1 }`
  - Response: `{ "message": "Transaction added successfully" }`

- **DELETE /delete/:id**: Delete a transaction by ID.
  - Response: `{ "message": "Transaction deleted successfully" }`

## Usage

1. **Login**: Use the `/login` endpoint to authenticate and receive a JWT. Store the token in cookies for subsequent requests.
2. **Add Transactions**: Use the `/add` endpoint to add earnings or expenses.
3. **View Transactions**: The frontend will automatically fetch and display transactions.
4. **Delete Transactions**: Click the delete button next to a transaction to remove it.

## Contributing

Feel free to open issues or submit pull requests for any improvements or bug fixes. Ensure to follow coding standards and provide clear commit messages.
