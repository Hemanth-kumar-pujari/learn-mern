import express from 'express';
import bodyParser from 'body-parser';
import mongoose from 'mongoose';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import { deleteRoute } from './routes/Delete.js';
import { testRoute } from './routes/Test.js';
import { LoginRoute } from './routes/Login.js';
import { registerRoute } from './routes/RegisterRoute.js';
import { dataRoute } from './routes/UploadDataRoute.js';
import { getalldataroute } from './routes/GetAllData.js';
import { deleteById } from './routes/DeleteOne.js';
const app = express();
app.use(cors({ origin: true, credentials: true })); // Ensure credentials are allowed
app.use(bodyParser.json());
app.use(cookieParser());
mongoose.connect(
  "Your_mongo_db_url",
  {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  }
);
app.post("/test", testRoute);
app.post("/login", LoginRoute);
app.post("/register", registerRoute);
app.post("/data", dataRoute);
// app.delete("/delete", deleteRoute);
app.delete("/delete/:id", deleteById);
app.get("/all",getalldataroute);
app.listen(3000, () => {
  console.log('Server is running on port 3000');
});
