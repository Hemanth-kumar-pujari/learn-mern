import mongoose from "mongoose";
import User from "./User.js";
const DataSchema = new mongoose.Schema({
    amount: {
        type: Number, // Correct type is Number
        required: true,
    },
    title: {
        type: String, // Correct type is String
        required: true, // Adding required true if needed
    },
    description: {
        type: String, // Correct type is String
        required: true, // Adding required true if needed
    },
    type: {
        type: Number, // Correct type is Number
        required: true, // Adding required true if needed
    },
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true, // Assuming every Data entry must be associated with a User
    }
});

const Data = mongoose.model('Data', DataSchema);
export default Data;