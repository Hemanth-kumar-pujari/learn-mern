import { Router } from "express";
import jwt from "jsonwebtoken";
import User from "../models/User.js";
import bcrypt from "bcrypt";
import cookieParser from 'cookie-parser';

const router = Router();
const jwtSecret = "your_jwt_secret";

router.post("/login", async function (req, res) {
  const { userName, password } = req.body;
  
  try {
    const userDoc = await User.findOne({ userName });
    
    if (userDoc) {
      const passOk = await bcrypt.compare(password, userDoc.password);
      if (passOk) {
        jwt.sign(
          { id: userDoc._id, userName: userDoc.userName },
          jwtSecret,
          { expiresIn: '1h' }, // Optional expiration time
          (err, token) => {
            if (err) {
              console.error("JWT Signing Error:", err);
              return res.status(500).json({ error: "Internal server error" });
            }
            
            res.cookie("token", token, {
              httpOnly: true,
              secure: process.env.NODE_ENV === 'production',
              sameSite: 'Strict',
            }).json(userDoc);
          }
        );
      } else {
        res.status(422).json("Password not correct");
      }
    } else {
      res.status(404).send("User not found");
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export const LoginRoute = router;
