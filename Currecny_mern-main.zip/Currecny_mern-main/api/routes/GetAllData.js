import mongoose from "mongoose";
import { Router } from "express";
import Data from "../models/Data.js";
import jwt from "jsonwebtoken";

const router = Router();

router.get('/all', async function(req, res) {
    const token = req.cookies.token;
    try {
        jwt.verify(token, "your_jwt_secret", async (err, data) => {
            if (err) {
                return res.status(403).json({ error: "Invalid token" });
            }
            const { id } = data;
            const response = await Data.find({ user: id });
            res.json(response);
        });
    } catch (err) {
        res.status(500).json({ error: "Internal server error" });
    }
});

export const getalldataroute=router;
