 import mongoose from "mongoose";
 import User from "../models/User.js";
 import Data from "../models/Data.js";
import { Router } from "express";
const router=Router();
router.delete("/delete", async function(req, res){
await User.deleteMany({});
await Data.deleteMany({});
res.status(200).send("Sucessfully deleted");
});

export const deleteRoute=router;
