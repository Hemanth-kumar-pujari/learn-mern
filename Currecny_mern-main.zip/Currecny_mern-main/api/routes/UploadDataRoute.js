import { Router } from 'express';
import jwt from 'jsonwebtoken';
import Data from '../models/Data.js';

const router = Router();
const jwtSecret = "your_jwt_secret";

router.post("/data", async function(req, res) {
  const token = req.cookies.token;
    // console.log(req.cookies);
  if (!token) {
    return res.status(401).json({ error: "No token provided" });
  }

  jwt.verify(token, jwtSecret, {}, async (err, userData) => {
    if (err) {
        
      return res.status(401).json({ error: "Invalid token" });
    }

    const { amount, title, description, type,user } = req.body;

    // Basic validation
    if (amount === undefined || title === undefined || description === undefined || type === undefined || user === undefined) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    try {
      const newData = await Data.create({ amount, title, description, type,user });
      res.status(201).json(newData);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Internal server error" });
    }
  });
});

export const dataRoute = router;
