import express from "express";
import bcrypt from "bcrypt";
import User from "../models/User.js";

const router = express.Router();

router.post("/register", async (req, res) => {
  const { userName, password } = req.body;
  console.log("Received data:", userName, password);

  if (!userName || !password) {
    return res.status(400).json({ error: "Username and password are required" });
  }

  try {
    // Generate a new salt for each password hash
    const salt = bcrypt.genSaltSync(10);
    const hashedPassword = bcrypt.hashSync(password, salt);
    
    // Create the user with the hashed password
    const user = await User.create({ userName, password: hashedPassword });
    res.status(201).json(user);
    console.log("User created:", user);
  } catch (err) {
    console.error("Error creating user:", err);
    res.status(422).json({ error: 'Unable to register user', details: err.message });
  }
});

export const registerRoute = router;
