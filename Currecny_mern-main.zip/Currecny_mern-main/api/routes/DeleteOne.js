import mongoose from "mongoose";
import { Router } from "express";
import Data from "../models/Data.js";
import jwt from "jsonwebtoken";

const router = Router();

router.delete('/delete/:id', async (req, res) => {
    const token = req.cookies.token;
    try {
        jwt.verify(token, "your_jwt_secret", async (err, decoded) => {
            if (err) {
                return res.status(403).json({ error: "Invalid token" });
            }
            const userId = decoded.id;
            const { id } = req.params; // Extract the entry ID from the route parameters
            const response = await Data.deleteOne({ _id: id, user: userId }); // Ensure the document belongs to the user
            if (response.deletedCount > 0) {
                res.json({ message: "Entry deleted successfully" });
            } else {
                res.status(404).json({ error: "Entry not found or not authorized" });
            }
        });
    } catch (err) {
        res.status(500).json({ error: "Internal server error" });
    }
});

export const deleteById=router;
