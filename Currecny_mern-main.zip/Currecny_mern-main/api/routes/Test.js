import express from 'express';
const router = express.Router();

router.get('/test', (req, res) => {
  console.log(req.cookies);
  console.log('Request received');
  res.send('Test route');
});

export const testRoute = router;
