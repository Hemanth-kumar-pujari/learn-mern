/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        customLightGray: '#F1F0E8',
        customBeige: '#EEE0C9',
        customLavender: '#ADC4CE',
        customBlue: '#96B6C5',
      },
    },
  },
  plugins: [],
}
