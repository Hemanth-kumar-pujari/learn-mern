import React, { useState, useContext } from "react";
import { Input, InputGroup, InputRightElement, Button, Box, VStack, useToast } from "@chakra-ui/react";
import { useNavigate } from "react-router-dom";
import { UserContext } from "./UserContext";
import axios from "axios";

export default function Register() {
  const [showPassword, setShowPassword] = useState(false);
  const [showRePassword, setShowRePassword] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [rePassword, setRePassword] = useState("");
  const toast = useToast();
  const navigate = useNavigate();
  const { setUserData, setLoggedIn } = useContext(UserContext);

  const handlePasswordClick = () => setShowPassword(!showPassword);
  const handleRePasswordClick = () => setShowRePassword(!showRePassword);

  const handleSubmit = async () => {
    if (!username || !password || !rePassword) {
      toast({
        title: "All fields are required.",
        status: "error",
        duration: 2000,
        isClosable: true,
      });
    } else if (password !== rePassword) {
      toast({
        title: "Passwords do not match.",
        status: "error",
        duration: 2000,
        isClosable: true,
      });
    } else {
      try {
        const response=await axios.post("http://localhost:3000/register", { userName: username, password });
         setUserData(response.data);
        // setLoggedIn(true);
        toast({
          title: "Registered successfully.",
          status: "success",
          duration: 2000,
          isClosable: true,
        });
        navigate("/login");
      } catch (err) {
        toast({
          title: "Registration failed.",
          description: err.response?.data?.error || "Something went wrong.",
          status: "error",
          duration: 2000,
          isClosable: true,
        });
      }
    }
  };

  return (
    <Box
      display="flex"
      alignItems="center"
      justifyContent="center"
      h="100vh"
      bgGradient="linear(to-r, violet.500, fuchsia.500)" // Gradient background
      p={4}
    >
      <Box
        bg="white"
        p={8}
        borderRadius="lg"
        boxShadow="lg"
        width={{ base: "full", sm: "400px" }}
      >
        <VStack spacing={4} align="stretch">
          <Input
            variant="outline"
            placeholder="Username"
            borderColor="gray.300"
            focusBorderColor="purple.500"
            p={4}
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
          <InputGroup size="md">
            <Input
              pr="4.5rem"
              type={showPassword ? "text" : "password"}
              placeholder="Enter password"
              borderColor="gray.300"
              focusBorderColor="purple.500"
              p={4}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <InputRightElement width="4.5rem">
              <Button h="1.75rem" size="sm" onClick={handlePasswordClick} colorScheme="purple">
                {showPassword ? "Hide" : "Show"}
              </Button>
            </InputRightElement>
          </InputGroup>
          <InputGroup size="md">
            <Input
              pr="4.5rem"
              type={showRePassword ? "text" : "password"}
              placeholder="Re-enter password"
              borderColor="gray.300"
              focusBorderColor="purple.500"
              p={4}
              value={rePassword}
              onChange={(e) => setRePassword(e.target.value)}
            />
            <InputRightElement width="4.5rem">
              <Button h="1.75rem" size="sm" onClick={handleRePasswordClick} colorScheme="purple">
                {showRePassword ? "Hide" : "Show"}
              </Button>
            </InputRightElement>
          </InputGroup>
          <Button colorScheme="purple" size="lg" mt={4} onClick={handleSubmit}>
            Register
          </Button>
        </VStack>
      </Box>
    </Box>
  );
}
