// src/UserContext.js
import React, { createContext, useState } from 'react';

// Create a Context for user authentication
export const UserContext = createContext();

// Create a Context Provider component
export const UserProvider = ({ children }) => {
  const [loggedIn, setLoggedIn] = useState(false);
  const [userData, setUserData] = useState(null); 
  // Store additional user data if needed

  return (
    <UserContext.Provider value={{ loggedIn, setLoggedIn, userData, setUserData }}>
      {children}
    </UserContext.Provider>
  );
};
