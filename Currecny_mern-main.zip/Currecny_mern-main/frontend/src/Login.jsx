import React, { useState, useContext } from "react";
import { Input, InputGroup, InputRightElement, Button, Box, VStack, useToast } from "@chakra-ui/react";
import { Link, useNavigate } from "react-router-dom";
import { UserContext } from "./UserContext";
import axios from "axios";
export default function Login() {
  const navigate = useNavigate();
  const [show, setShow] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const toast = useToast();
  const { setLoggedIn, setUserData } = useContext(UserContext);

  const handleClick = () => setShow(!show);

  const handleSubmit = async () => {
    if (username && password) {
      try {
        const response = await axios.post("http://localhost:3000/login", {
          userName: username,
          password: password
        });

        if (response.status === 200) {
          toast({
            title: "Login successful.",
            status: "success",
            duration: 2000,
            isClosable: true,
          });

           setUserData(response.data); // Assuming the response contains user data
          setLoggedIn(true);
          navigate("/");
        }
      } catch (error) {
        if (error.response) {
          if (error.response.status === 422) {
            toast({
              title: "Incorrect password.",
              status: "error",
              duration: 2000,
              isClosable: true,
            });
          } else if (error.response.status === 404) {
            toast({
              title: "Username not found.",
              status: "error",
              duration: 2000,
              isClosable: true,
            });err.message
          } else {
            toast({
              title: "An error occurred.",
              status: "error",
              duration: 2000,
              isClosable: true,
            });
          }
        } else {
          toast({
            title: "An error occurred.",
            status: "error",
            duration: 2000,
            isClosable: true,
          });
        }
      }
    } else {
      toast({
        title: "Please enter both username and password.",
        status: "error",
        duration: 2000,
        isClosable: true,
      });
    }
  };

  return (
    <Box
      display="flex"
      alignItems="center"
      justifyContent="center"
      h="100vh"
      bgGradient="linear(to-r, violet.500, fuchsia.500)" // Gradient background
      p={4}
    >
      <Box
        bg="white"
        p={8}
        borderRadius="lg"
        boxShadow="lg"
        width={{ base: "full", sm: "400px" }}
      >
        <VStack spacing={4} align="stretch">
          <Input
            variant="outline"
            placeholder="Username"
            borderColor="gray.300"
            focusBorderColor="purple.500"
            p={4}
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
          <InputGroup size="md">
            <Input
              pr="4.5rem"
              type={show ? "text" : "password"}
              placeholder="Enter password"
              borderColor="gray.300"
              focusBorderColor="purple.500"
              p={4}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <InputRightElement width="4.5rem">
              <Button h="1.75rem" size="sm" onClick={handleClick} colorScheme="purple">
                {show ? "Hide" : "Show"}
              </Button>
            </InputRightElement>
          </InputGroup>
          <Button colorScheme="purple" size="lg" mt={4} onClick={handleSubmit}>
            Submit
          </Button>
          
          <Link to="/register">
            Don't have an account? <span style={{ color: 'blue' }}>Register</span>
          </Link>
        </VStack>
      </Box>
    </Box>
  );
}
