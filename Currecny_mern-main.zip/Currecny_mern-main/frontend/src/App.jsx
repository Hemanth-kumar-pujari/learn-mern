import React, { useEffect } from "react";
import { Box } from "@chakra-ui/react";
import { Routes, Route } from "react-router-dom";
import Navbar from "./Navbar";
import Login from "./Login";
import Register from "./Register";
import Earn from "./pages/Earn";
import Home from "./pages/Home";
import Spend from "./pages/Spend";
import { UserProvider } from "./UserContext"; // Import the UserProvider
import { useState } from "react";
import Result from "./pages/Result";
import axios from "axios";
// axios.defaults.baseURL = "http://localhost:000";
axios.defaults.withCredentials = true;
function App() {
  const [transaction,setTransaction]=useState({});
  useEffect(()=>{
    
  },[])
  return (
    <UserProvider> {/* Wrap your component tree with UserProvider */}
      <div className="bg-gradient-to-r from-violet-500 to-fuchsia-500">
        <Box className="flex flex-col h-auto">
          <Navbar />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/earn" element={<Earn  data={transaction} setData={setTransaction} />} />
            <Route path="/spend" element={<Spend data={transaction} setData={setTransaction} />} />
            <Route path="/result" element={<Result data={transaction} setData={setTransaction} />} />
          </Routes>
        </Box>
      </div>
    </UserProvider>
  );
}

export default App;
