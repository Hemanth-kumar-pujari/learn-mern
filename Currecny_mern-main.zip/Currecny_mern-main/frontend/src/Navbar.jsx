import React, { useContext } from "react";
import { Box, Button } from "@chakra-ui/react";
import { Link, useLocation } from "react-router-dom";
import { UserContext } from "./UserContext";
import "./App.css";

function Navbar() {
  const { loggedIn,userData } = useContext(UserContext); // Consume context
  const location = useLocation();

  // Function to determine if the link is active
  const isActive = (path) => location.pathname === path;
 
  return (
    <div className="w-full fixed top-0 left-0 right-0 z-10">
      <div className="font-sans text-white bg-gradient-to-r from-violet-500 to-fuchsia-500 w-full flex justify-between items-center p-4">
        <Box p="2" fontWeight="bold" fontSize="3xl">
          <Link to={"/"}>Save Money</Link>
        </Box>

        {loggedIn ? (
          <div className="flex gap-8 justify-between grow-8 px-5">
            <Link to="/earn">
              <Button
                colorScheme={isActive("/earn") ? "gold" : "white"}
                variant="link"
                textDecoration={isActive("/earn") ? "underline" : "none"}
                _hover={{ textDecoration: "underline" }}
              >
                Earn
              </Button>
            </Link>
            <Link to="/spend">
              <Button
                colorScheme={isActive("/spend") ? "gold" : "white"}
                variant="link"
                textDecoration={isActive("/spend") ? "underline" : "none"}
                _hover={{ textDecoration: "underline" }}
              >
                Spend
              </Button>
            </Link>
            <Link to="/result">
              <Button
                colorScheme={isActive("/result") ? "gold" : "white"}
                variant="link"
                textDecoration={isActive("/result") ? "underline" : "none"}
                _hover={{ textDecoration: "underline" }}
              >
                Result
              </Button>
            </Link>
            <div className="font-bold text-orange-100">
              {userData.userName}
            </div>
          </div>
        ) : (
          <div className="flex gap-4">
            <Link to={"/login"}>
              <Button
                colorScheme={isActive("/login") ? "violet" : "violet"}
                variant={isActive("/login") ? "solid" : "outline"}
                mt={"15px"}
                textDecoration={isActive("/login") ? "underline" : "none"}
                _hover={{ textDecoration: "underline" }}
              >
                Login
              </Button>
            </Link>
            <Link to={"/register"}>
              <Button
                colorScheme="violet.900"
                variant={isActive("/register") ? "solid" : "outline"}
                mt={"15px"}
                textDecoration={isActive("/register") ? "underline" : "none"}
                _hover={{ textDecoration: "underline" }}
              >
                Register
              </Button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}

export default Navbar;
