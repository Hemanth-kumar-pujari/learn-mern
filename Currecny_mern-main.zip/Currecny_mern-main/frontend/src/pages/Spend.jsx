import React, { useState, useContext, useEffect } from "react";
import { Box, Input, Textarea, Button, VStack, useToast } from '@chakra-ui/react';
import { UserContext } from "../UserContext.jsx";
import { useNavigate } from "react-router-dom";
import axios from "axios";

export default function Spend({ setData, data }) {
  const [amount, setAmount] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const toast = useToast();
  const navigate = useNavigate();
  const { loggedIn ,userData} = useContext(UserContext);

  useEffect(() => {
    if (!loggedIn) {
      navigate("/");
    }
  }, [loggedIn, navigate]);

  const handleAdd = async () => {
    if (!amount || isNaN(amount) || parseFloat(amount) <= 0) {
      toast({
        title: "Invalid amount.",
        description: "Please enter a valid amount greater than zero.",
        status: "error",
        duration: 2000,
        isClosable: true,
      });
      return;
    }

    if (amount && title && description) {
      const newEntry = { amount, title, description, type: 0 }; // 1 for Spend

      try {
        await axios.post("http://localhost:3000/data", { amount, title, description, type: 0,user: userData._id });
        toast({
          title: "Entry added.",
          status: "success",
          duration: 2000,
          isClosable: true,
        });

        // Clear form fields
        setAmount('');
        setTitle('');
        setDescription('');
      } catch (error) {
        toast({
          title: "Error adding entry.",
          description: error.response?.data?.error || error.message || "An unexpected error occurred.",
          status: "error",
          duration: 2000,
          isClosable: true,
        });
      }
    } else {
      toast({
        title: "Please fill in all fields.",
        status: "error",
        duration: 2000,
        isClosable: true,
      });
    }
  };

  return (
    <Box
      display="flex"
      flexDirection="column"
      alignItems="center"
      justifyContent="center"
      h="100vh"
      bgGradient="linear(to-r, violet.500, fuchsia.500)"
      p={4}
    >
      <Box
        bg="white"
        p={8}
        borderRadius="lg"
        boxShadow="lg"
        width={{ base: "full", sm: "400px" }}
        mb={4}
      >
        <VStack spacing={4} align="stretch">
          <Input
            variant="outline"
            placeholder="Amount"
            borderColor="gray.300"
            focusBorderColor="purple.500"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />
          <Input
            variant="outline"
            placeholder="Title"
            borderColor="gray.300"
            focusBorderColor="purple.500"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
          <Textarea
            placeholder="Description"
            borderColor="gray.300"
            focusBorderColor="purple.500"
            rows={4}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
          <Button colorScheme="purple" size="lg" onClick={handleAdd}>
            Add Entry
          </Button>
        </VStack>
      </Box>
    </Box>
  );
}
