import React, { useContext, useEffect, useState } from "react";
import {
  Box,
  TableContainer,
  Table,
  Thead,
  Tbody,
  Tfoot,
  Tr,
  Th,
  Td,
  TableCaption,
  Text,
  Button,
} from "@chakra-ui/react";
import { UserContext } from "../UserContext";
import { useNavigate } from "react-router-dom";
import axios from "axios";

export default function Result() {
  const { loggedIn } = useContext(UserContext);
  const navigate = useNavigate();
  const [data, setData] = useState({ entries: [] });

  useEffect(() => {
    if (!loggedIn) {
      navigate("/login");
      return;
    }

    const fetchTransactions = async () => {
      try {
        const response = await axios.get("http://localhost:3000/all");
        setData({ entries: response.data });
        console.log(response.data);
      } catch (error) {
        console.error("Error fetching transactions:", error);
      }
    };
    fetchTransactions();
  }, [loggedIn, navigate]);

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:3000/delete/${id}`);
      setData((prevData) => ({
        entries: prevData.entries.filter((entry) => entry._id !== id),
      }));
    } catch (error) {
      console.error("Error deleting transaction:", error);
    }
  };

  // Ensure data.entries is an array
  const entries = Array.isArray(data.entries) ? data.entries : [];

  // Calculate totals
  const totals = entries.reduce(
    (acc, entry) => {
      if (entry.type === 1) {
        acc.earned += parseFloat(entry.amount) || 0;
      } else {
        acc.spent += parseFloat(entry.amount) || 0;
      }
      return acc;
    },
    { earned: 0, spent: 0 }
  );

  return (
    <Box
      display="flex"
      flexDirection="column"
      alignItems="center"
      justifyContent="center"
      h="100vh"
      p={4}
      overflow="auto"
      w="full"
    >
      {entries.length > 0 ? (
        <TableContainer maxH="80vh" overflowY="auto" w="full">
          <Table variant="striped" colorScheme="teal" w="full">
            <TableCaption>Your data entries</TableCaption>
            <Thead>
              <Tr>
                <Th>Amount</Th>
                <Th>Title</Th>
                <Th>Description</Th>
                <Th>Type</Th>
                <Th>Update</Th>
              </Tr>
            </Thead>
            <Tbody>
              {entries.map((entry, index) => (
                <Tr
                  key={index}
                  bg={entry.type === 1 ? "green.50" : "red.50"}
                  _hover={{ bg: entry.type === 1 ? "green.100" : "red.100" }}
                >
                  <Td>{entry.amount}</Td>
                  <Td>{entry.title}</Td>
                  <Td maxW="200px">
                    <Text isTruncated>{entry.description}</Text>
                  </Td>
                  <Td>{entry.type === 1 ? "Earn" : "Spend"}</Td>
                  <Td>
                    <Button
                      colorScheme=""
                      textColor={"red"}
                      onClick={() => handleDelete(entry._id)}
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        strokeWidth={1.5}
                        stroke="currentColor"
                        className="size-6"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0"
                        />
                      </svg>
                    </Button>
                  </Td>
                </Tr>
              ))}
            </Tbody>
            <Tfoot>
              <Tr>
                <Th>Amount</Th>
                <Th>Title</Th>
                <Th>Description</Th>
                <Th>Type</Th>
              </Tr>
              <Tr>
                <Td colSpan={3} textAlign="right" fontWeight="bold">
                  Total Earned:
                </Td>
                <Td fontWeight="bold" color="orange.900">
                  {totals.earned.toFixed(2)}
                </Td>
              </Tr>
              <Tr>
                <Td colSpan={3} textAlign="right" fontWeight="bold">
                  Total Spent:
                </Td>
                <Td fontWeight="bold" color="blue.900">
                  {totals.spent.toFixed(2)}
                </Td>
              </Tr>
            </Tfoot>
          </Table>
        </TableContainer>
      ) : (
        <Box fontWeight="bold" fontSize="2xl" mt={4}>
          No data
        </Box>
      )}
    </Box>
  );
}
