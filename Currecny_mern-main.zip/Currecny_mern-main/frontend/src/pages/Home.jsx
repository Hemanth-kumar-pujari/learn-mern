import React from 'react';
import { Box, VStack } from '@chakra-ui/react';

export default function Home() {
  return (
    <Box
      display="flex"
      alignItems="center"
      justifyContent="center"
      h="100vh"
      bgGradient="linear(to-r, violet.500, fuchsia.500)" // Gradient background
      p={4}
    >
      <VStack spacing={4} align="center">
        <h1 className="text-white text-4xl md:text-5xl font-extrabold italic text-center">
          Welcome to your money manager
          <br />
          and you will save time
        </h1>
      </VStack>
    </Box>
  );
}
