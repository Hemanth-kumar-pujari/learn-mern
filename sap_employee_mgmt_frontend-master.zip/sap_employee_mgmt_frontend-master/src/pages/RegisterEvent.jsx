import React, { useState } from 'react';
import useGetAllEvents from '../utils/useGetAllEvents.js';
import useRegisterEvent from '../utils/useRegisterEvent.js';

function RegisterEvent() {
  const { events, error: loadError } = useGetAllEvents();
  const { registerEvent, error: submitError, loading } = useRegisterEvent();

  const [employeeId, setEmployeeId] = useState('');
  const [selectedEvent, setSelectedEvent] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  if (loadError) {
    return <div className="text-red-300">Error loading events.</div>;
  }
  if (!events) {
    return <div className="text-white">Loading events...</div>;
  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSuccessMsg('');

    if (!employeeId || !selectedEvent) {
      alert('Please fill all fields');
      return;
    }

    const registrationData = {
      REGISTRATION_ID: `REG_${Date.now()}`, // or use UUID in real case
      EMPLOYEE_ID: employeeId,
      EVENT_NAME: selectedEvent,
      REGISTRATION_DATE: new Date().toISOString().slice(0, 10).replace(/-/g, ''), // YYYYMMDD format
      STATUS: 'PENDING' // example status
    };

    try {
      await registerEvent(registrationData);
      setSuccessMsg('Registration successful!');
      setEmployeeId('');
      setSelectedEvent('');
    } catch {
      // error handled by hook and submitError
    }
  };

  return (
    <div className="max-w-md mx-auto p-6  text-white rounded shadow">
      <h2 className="text-2xl font-semibold mb-4">Register for Event</h2>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="employeeId" className="block mb-1 font-medium">
            Employee ID
          </label>
          <input
            id="employeeId"
            type="text"
            value={employeeId}
            onChange={(e) => setEmployeeId(e.target.value)}
            className="w-full p-2 rounded text-black"
            placeholder="Enter your Employee ID"
          />
        </div>

        <div>
          <label htmlFor="eventSelect" className="block mb-1 font-medium">
            Select Event
          </label>
          <select
            id="eventSelect"
            value={selectedEvent}
            onChange={(e) => setSelectedEvent(e.target.value)}
            className="w-full p-2 rounded text-black"
          >
            <option value="">-- Choose an event --</option>
            {events.map((event, i) => (
              <option key={i} value={event.ddtext || event.EVENT_NAME || event.name}>
                {event.ddtext || event.EVENT_NAME || event.name}
              </option>
            ))}
          </select>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded font-semibold"
        >
          {loading ? 'Registering...' : 'Register'}
        </button>

        {submitError && <p className="text-red-400 mt-2">Error: {submitError.message}</p>}
        {successMsg && <p className="text-green-400 mt-2">{successMsg}</p>}
      </form>
    </div>
  );
}

export default RegisterEvent;
