import React, { useState } from 'react';
import useAddEmployee from '../utils/useAddEmployee';

function AddEmployee() {
  const [formData, setFormData] = useState({
    EMPLOYEE_ID: '',
    NAME: '',
    EMAIL: '',
    DEPARTMENT: '',
    MANAGER_ID: '',
    ZPHONE_NUMBER: '',
    HIRE_DATE: '',
    JOB_TITLE: '',
    STATUS: 'A'
  });

  const { addEmployee, error, loading } = useAddEmployee();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const result = await addEmployee(formData);
    if (result != null) {
      alert('Employee added successfully!');
      setFormData({
        EMPLOYEE_ID: '',
        NAME: '',
        EMAIL: '',
        DEPARTMENT: '',
        MANAGER_ID: '',
        ZPHONE_NUMBER: '',
        HIRE_DATE: '',
        JOB_TITLE: '',
        STATUS: 'A'
      });
    }
    else{
      alert(result.message)
    }
  };

  return (
    <div className="p-6 max-w-xl mx-auto border-blue-800 rounded shadow">
      <h2 className="text-2xl font-semibold mb-4">Add New Employee</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        {Object.keys(formData).map((field) => (
          <div key={field}>
            <label className="block font-medium capitalize text-white">
              {field.replace(/_/g, ' ')}
            </label>
            <input
              type="text"
              name={field}
              value={formData[field]}
              onChange={handleChange}
              className="mt-1 w-full p-2 border border-gray-300 rounded"
            />
          </div>
        ))}
        <button
          type="submit"
          disabled={loading}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
          {loading ? 'Submitting...' : 'Add Employee'}
        </button>
        {error && <p className="text-red-500 mt-2">Error: {error}</p>}
      </form>
    </div>
  );
}

export default AddEmployee;
