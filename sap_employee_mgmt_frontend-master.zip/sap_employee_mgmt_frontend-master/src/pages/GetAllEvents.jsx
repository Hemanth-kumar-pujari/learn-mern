import React from 'react';
import useGetAllEvents from '../utils/useGetAllEvents';

function GetAllEvents() {
  const { events, error } = useGetAllEvents();

  if (error) {
    return <div className="text-red-300">Error loading events.</div>;
  }

  if (!events) {
    return <div className="text-white">Loading events...</div>;
  }

  return (
    <div className="p-6  min-h-screen">
      <h2 className="text-3xl text-white font-bold mb-6">Event Names</h2>
      <div className="overflow-x-auto">
        <table className="min-w-full table-auto border border-blue-700  text-white">
          <thead>
            <tr>
              <th className="px-6 py-3 text-left border-b border-blue-600 text-blue-200 uppercase tracking-wider">
                ddtext
              </th>
            </tr>
          </thead>
          <tbody>
            {events.map((event, index) => (
              <tr key={index} className="hover:bg-blue-700">
                <td className="px-6 py-3 border-b border-blue-600">{event.ddtext}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default GetAllEvents;
