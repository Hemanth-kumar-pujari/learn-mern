import React from 'react';
import getEmployees from '../utils/getEmployees';

function DisplayEmployees() {
  const { employees, error } = getEmployees();

  if (error) {
    return <div className="text-red-500 text-center mt-4">{error}</div>;
  }

  if (!employees) {
    return <div className="text-gray-500 text-center mt-4">Loading...</div>;
  }

  return (
    <div className="container mx-auto p-4">
      <h2 className="text-2xl font-bold mb-4 text-white">Employee Directory</h2>
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white border border-blue-700 shadow-md rounded-lg">
          <thead className="bg-gray-100 text-teal-700">
            <tr>
              <th className="py-2 px-4 text-left">Employee ID</th>
              <th className="py-2 px-4 text-left">Name</th>
              <th className="py-2 px-4 text-left">Email</th>
              <th className="py-2 px-4 text-left">Phone</th>
              <th className="py-2 px-4 text-left">Department</th>
              <th className="py-2 px-4 text-left">Job Title</th>
              <th className="py-2 px-4 text-left">Manager ID</th>
              <th className="py-2 px-4 text-left">Hire Date</th>
              <th className="py-2 px-4 text-left">Status</th>
            </tr>
          </thead>
          <tbody>
            {employees.map((emp) => (
              <tr key={emp.employeeId} className="border-t hover:bg-gray-50 text-purple-500 border-blue-700">
                <td className="py-2 px-4">{emp.employeeId}</td>
                <td className="py-2 px-4">{emp.name}</td>
                <td className="py-2 px-4">{emp.email}</td>
                <td className="py-2 px-4">{emp.zphoneNumber}</td>
                <td className="py-2 px-4">{emp.department}</td>
                <td className="py-2 px-4">{emp.jobTitle}</td>
                <td className="py-2 px-4">{emp.managerId}</td>
                <td className="py-2 px-4">{emp.hireDate}</td>
                <td className="py-2 px-4">{emp.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default DisplayEmployees;
