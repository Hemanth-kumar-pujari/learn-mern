import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import axios from 'axios';
import LandingPage from './components/LandingPage';
axios.defaults.baseURL = "http://localhost:3000";
axios.defaults.withCredentials = true;
import { Route,Routes } from 'react-router-dom';
import DisplayEmployees from './pages/DisplayEmployees';
import AddEmployee from './pages/AddEmployee';
import RegisterEvent from './pages/RegisterEvent'
import GetAllEvents from './pages/GetAllEvents';
function App() {
  const [count, setCount] = useState(0)

  return (
 <>
 
    <LandingPage/>

    <Routes>
      <Route path="/display-employee" element={<DisplayEmployees/>} />
      
      
      <Route path="/add-employee" element={<AddEmployee/>}/>
        <Route path="/register-event" element ={<RegisterEvent/>}/>
        <Route path="/get-events" element={ <GetAllEvents/>}/>
      
      
    </Routes>
 
 </>
  )
}

export default App
