import { useState } from 'react';
import axios from 'axios';

function useRegisterEvent() {
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const registerEvent = async (registrationData) => {
    setLoading(true);
    setError(null);
    try {
      const response = await axios.post('/event', registrationData); // adjust endpoint
      return response.data;
    } catch (err) {
      setError(err);
      throw err; // rethrow for component handling
    } finally {
      setLoading(false);
    }
  };

  return { registerEvent, error, loading };
}

export default useRegisterEvent;
