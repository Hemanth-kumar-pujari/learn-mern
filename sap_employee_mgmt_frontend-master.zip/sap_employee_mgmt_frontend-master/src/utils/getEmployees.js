import { useState, useEffect } from 'react';
import axios from 'axios';

const useEmployees = () => {
  const [employees, setEmployees] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const response = await axios.get('/employees');
        setEmployees(response.data);
      } catch (e) {
        setError(e.message || 'Failed to fetch employees');
      }
    };

    fetchEmployees();
  }, []);

  return { employees, error };
};

export default useEmployees;
