import React from 'react'
import axios from 'axios';
import { useState,useEffect } from 'react';
function useGetAllEvents() {
     const [events, setevents] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchevents = async () => {
      try {
        const response = await axios.get('/events');
        setevents(response.data);
      } catch (e) {
        setError(e.message || 'Failed to fetch events');
      }
    };

    fetchevents();
  }, []);

  return { events, error };

    
}

export default useGetAllEvents