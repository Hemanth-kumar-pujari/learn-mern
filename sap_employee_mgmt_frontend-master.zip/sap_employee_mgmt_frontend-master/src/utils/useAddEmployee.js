import { useState } from 'react';
import axios from 'axios';

function useAddEmployee() {
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const addEmployee = async (employeeData) => {
    setLoading(true);
    setError(null);

    try {
      const response = await axios.post('/employee', employeeData); // adjust endpoint
      console.log(response)
      if(response.status == 500){
        setError(response.data)
        // console.log(response)
        return null;
      }
      
      return response.data;
    } catch (err) {
        // console.log(err.response.data.error)
      setError(err.response.data.error);
    } finally {
      setLoading(false);
    }
  };

  return { addEmployee, error, loading };
}

export default useAddEmployee;
