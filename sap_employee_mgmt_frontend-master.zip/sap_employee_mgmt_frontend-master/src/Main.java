class Solution {
    public long shiftDistance(String s, String t, int[] nextCost, int[] previousCost) {
        int forward =0,backward=0;
        int n= s.length();

        for(int i=0;i<n;i++){
            
        }
         
    }
}©leetcode