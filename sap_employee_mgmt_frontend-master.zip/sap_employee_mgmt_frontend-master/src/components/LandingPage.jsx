import React from 'react';
import { Link } from 'react-router-dom';

import Header from './Header';
function LandingPage() {
  const buttonClass = 'bg-blue-900 text-teal-500 rounded-full p-2 px-4 text-md cursor-pointer hover:opacity-50 active:opacity-40 text-center min-w-[200px] border-2 border-black/50';

  return (
    <div className='relative flex flex-wrap text-gray-50 w-full justify-center gap-4 font-sans p-10 sm:flex-col md:flex-col lg:flex-row xl:flex-row'>
      <Header/>
      <Link to="/display-employee" className={buttonClass}>
       Display All Employees
      </Link>

      <Link to="/get-events" className={buttonClass}>
        Get All Events
      </Link>

      <Link to="/add-employee" className={buttonClass}>
        Add an Employee
      </Link>

      <Link to="/register-event" className={buttonClass}>
        Register for an Event
      </Link>
      
    </div>
  );
}

export default LandingPage;
